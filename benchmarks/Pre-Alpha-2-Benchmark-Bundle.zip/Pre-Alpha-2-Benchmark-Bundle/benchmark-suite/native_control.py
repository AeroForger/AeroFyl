#!/usr/bin/env python3
"""Compare fixed-input AeroFyl with actual Sydrogen direct-native and Cranelift output."""
from pathlib import Path
import argparse,json,os,subprocess,time,random,statistics
p=argparse.ArgumentParser();p.add_argument('--aero',required=True);p.add_argument('--furnace',required=True);p.add_argument('--rounds',type=int,default=21);p.add_argument('--reuse-binaries',action='store_true');a=p.parse_args()
a.aero=str(Path(a.aero).resolve());a.furnace=str(Path(a.furnace).resolve());root=Path(__file__).resolve().parent
r=json.loads((root/'results.json').read_text());cases=json.loads((root/'cases.json').read_text());os.sched_setaffinity(0,{r['cpu_affinity']})
outputs={};builds={};sizes={};elf={}
for name,case in cases.items():
    n,seed=case['n'],case['seed'];outputs[name]={};builds[name]={};sizes[name]={};elf[name]={}
    fyl=root/'sources'/f'{name}.fixed.fyl';fyl.write_text((root/'sources'/f'{name}.fyl').read_text().replace('int n=input(int); int seed=input(int);',f'int n={n}; int seed={seed};'))
    syd=root/'sources'/f'{name}.fixed.anvil';syd.write_text((root/'sources'/f'{name}.anvil').read_text().replace('Int n=Input(Int); Int seed=Input(Int);',f'Int n={n}; Int seed={seed};'))
    for label in ['AeroFyl-fixed','Sydrogen-direct-native-fixed','Sydrogen-cranelift-fixed']:
        out=root/'bin'/f'{name}.{label}'
        cmd=[a.aero,'compile',str(fyl),'-o',str(out)] if label=='AeroFyl-fixed' else [a.furnace,'compile',str(syd),'linux','--backend','native' if label=='Sydrogen-direct-native-fixed' else 'cranelift']
        if a.reuse_binaries:
            assert out.exists(),out
            builds[name][label]={'reused_existing_binary':True,'original_build':json.loads((root/'native-control-first-run.json').read_text())['builds'][name][label]}
        else:
            # Pre-Alpha-2 note: same retry rationale as run.py. The closing
            # bootstrap can exceed the per-attempt budget nondeterministically.
            attempts=[];q=None
            for attempt in range(1,11 if label=='AeroFyl-fixed' else 2):
                try:
                    q=subprocess.run(cmd,cwd=root/'bin',capture_output=True,text=True,timeout=120)
                except subprocess.TimeoutExpired:
                    attempts.append({'attempt':attempt,'outcome':'timeout_120s'})
                    print(f'Build {name}/{label} attempt {attempt} timed out, retrying',flush=True)
                    continue
                assert q.returncode==0,(name,label,q.stderr)
                attempts.append({'attempt':attempt,'outcome':'ok'})
                break
            else:
                raise RuntimeError(f'build failed after retries {name} {label}')
            if label!='AeroFyl-fixed':(root/'bin'/f'{name}.fixed').replace(out)
            builds[name][label]={'command':cmd,'stdout':q.stdout,'stderr':q.stderr,'attempts':attempts}
        outputs[name][label]=str(out);sizes[name][label]=out.stat().st_size
        h=subprocess.check_output(['readelf','-l',str(out)],text=True);elf[name][label]=h
        if label in ['AeroFyl-fixed','Sydrogen-direct-native-fixed']:assert 'INTERP' not in h,(name,label,h)
        elif label=='Sydrogen-cranelift-fixed':assert 'INTERP' in h,(name,label,h)

def one(name,label):
    start=time.perf_counter_ns();q=subprocess.run([outputs[name][label]],capture_output=True,text=True,timeout=60);ms=(time.perf_counter_ns()-start)/1e6
    expected=r['validation'][name][-1]['expected'];assert q.returncode==0 and not q.stderr and q.stdout.strip()==str(expected),(name,label,q.stdout,q.stderr)
    return ms
raw={};summary={};rng=random.Random(4203)
for name in cases:
    raw[name]={label:[] for label in outputs[name]}
    for roundnum in range(a.rounds+2):
        order=list(outputs[name]);rng.shuffle(order)
        for label in order:
            ms=one(name,label)
            if roundnum>=2:raw[name][label].append(ms)
    summary[name]={label:{'median_ms':statistics.median(v),'min_ms':min(v),'max_ms':max(v)} for label,v in raw[name].items()}
    print(name,summary[name],flush=True)
(root/'native-control.json').write_text(json.dumps({'description':'Fixed literal inputs in both languages; a separate timing phase. Do not pool with stdin tests.','rounds':a.rounds,'warmups':2,'cpu':r['cpu_affinity'],'builds':builds,'file_bytes':sizes,'program_headers':elf,'samples':raw,'summary':summary},indent=2))
