# AeroFyl Pre-Alpha-2 benchmark package (final Rust bootstrap measurement)

Read `AeroFyl-Benchmark-Report.md` for the four requested comparisons, protocol, environment, backend caveat and limitations.

This bundle repeats the Pre-Alpha suite unchanged against the closing Rust bootstrap revision. Rust bootstrap development has stopped after this point.

The bundle contains all workload sources, checked timing harnesses, exact commands, raw samples and logs. Compilers and downloaded toolchains are excluded.
