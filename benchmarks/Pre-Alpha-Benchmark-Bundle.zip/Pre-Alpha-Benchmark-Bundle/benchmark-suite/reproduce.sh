#!/usr/bin/env bash
set -eu
# Prerequisites: Linux x86-64, GCC, Python 3, rustup with Rust 1.99.0,
# Go 1.27.1 on PATH, git, readelf. No repositories are modified remotely.
script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
checkout_dir="$script_dir/checkouts"
mkdir -p "$checkout_dir"
if [ ! -d "$checkout_dir/AeroFyl/.git" ]; then
    git clone https://github.com/AeroForger/AeroFyl.git "$checkout_dir/AeroFyl"
fi
if [ ! -d "$checkout_dir/Sydrogen/.git" ]; then
    git clone https://github.com/AeroForger/Sydrogen.git "$checkout_dir/Sydrogen"
fi
git -C "$checkout_dir/AeroFyl" checkout --detach 10d75e72f73158da9cc9897b5c273c70ef5a45c0
git -C "$checkout_dir/Sydrogen" checkout --detach 8e8e31a448c1f98fa5e879f12a2bd916c4bb4bc6
cargo +1.99.0 build --manifest-path "$checkout_dir/AeroFyl/Cargo.toml" --workspace --release --locked
cargo +1.99.0 build --manifest-path "$checkout_dir/Sydrogen/Cargo.toml" --release --locked
python3 "$script_dir/capture_environment.py" "$checkout_dir/AeroFyl" "$checkout_dir/Sydrogen"
python3 "$script_dir/generate.py"
python3 "$script_dir/run.py" --aero "$checkout_dir/AeroFyl/target/release/aerofyl-bootstrap" --furnace "$checkout_dir/Sydrogen/target/release/furnace" --go go
python3 "$script_dir/width_control.py" --go go
python3 "$script_dir/native_control.py" --aero "$checkout_dir/AeroFyl/target/release/aerofyl-bootstrap" --furnace "$checkout_dir/Sydrogen/target/release/furnace"
python3 "$script_dir/make_report.py"
