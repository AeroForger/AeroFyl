#include <stdio.h>
#include <stdint.h>
#include <inttypes.h>

int32_t work(int32_t n,int32_t seed) { int32_t i=0; int32_t x=seed; while(i<n) { if(x<500001) { x=x*31+17; x=x-(x/1000003)*1000003; } else { x=x*37+11; x=x-(x/1000003)*1000003; } i=i+1; } return x; }
int main(void) { int32_t n,seed; if(scanf("%" SCNd32 " %" SCNd32,&n,&seed)!=2) return 2; printf("%" PRId32 "\n", work(n,seed)); return 0; }
