def work(n,seed):
    i=0
    x=seed
    while i<n:
        if i<n//2:
            x=x+3
        else:
            x=x-1
        i=i+1
    return x
if __name__=="__main__":
    import sys
    n,seed=map(int,sys.stdin.read().split())
    print(work(n,seed))
