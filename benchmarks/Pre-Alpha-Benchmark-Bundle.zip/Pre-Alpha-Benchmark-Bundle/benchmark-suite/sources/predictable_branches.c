#include <stdio.h>
#include <stdint.h>
#include <inttypes.h>

int64_t work(int64_t n,int64_t seed) { int64_t i=0; int64_t x=seed; while(i<n) { if(i<n/2) { x=x+3; } else { x=x-1; } i=i+1; } return x; }
int main(void) { int64_t n,seed; if(scanf("%" SCNd64 " %" SCNd64,&n,&seed)!=2) return 2; printf("%" PRId64 "\n", work(n,seed)); return 0; }
