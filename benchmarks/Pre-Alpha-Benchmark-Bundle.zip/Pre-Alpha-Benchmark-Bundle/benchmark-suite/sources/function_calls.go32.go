package main
import "fmt"
func step(x int32) int32 { y := int32(x*3+7); return y-(y/1000003)*1000003; }
func work(n int32,seed int32) int32 { i := int32(0); x := int32(seed); for (i<n) { x=step(x); i=i+1; }; return x; }
func main() { var n,seed int32; fmt.Scan(&n,&seed); fmt.Println(work(n,seed)) }
