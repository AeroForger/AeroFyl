package main
import "fmt"
func fib(x int64) int64 { if x<2 { return x; }; return fib(x-1)+fib(x-2); }
func work(n int64,seed int64) int64 { return fib(n)+seed; }
func main() { var n,seed int64; fmt.Scan(&n,&seed); fmt.Println(work(n,seed)) }
