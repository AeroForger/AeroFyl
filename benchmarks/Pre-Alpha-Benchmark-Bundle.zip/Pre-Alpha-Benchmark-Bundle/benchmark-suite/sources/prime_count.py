def work(n,seed):
    count=0
    candidate=2
    while candidate<=n:
        d=2
        prime=1
        while d*d<=candidate:
            if candidate-(candidate//d)*d==0:
                prime=0
            d=d+1
        count=count+prime
        candidate=candidate+1
    return count+seed
if __name__=="__main__":
    import sys
    n,seed=map(int,sys.stdin.read().split())
    print(work(n,seed))
