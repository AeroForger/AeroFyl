#include <stdio.h>
#include <stdint.h>
#include <inttypes.h>
int64_t step(int64_t x) { int64_t y=x*3+7; return y-(y/1000003)*1000003; }
int64_t work(int64_t n,int64_t seed) { int64_t i=0; int64_t x=seed; while(i<n) { x=step(x); i=i+1; } return x; }
int main(void) { int64_t n,seed; if(scanf("%" SCNd64 " %" SCNd64,&n,&seed)!=2) return 2; printf("%" PRId64 "\n", work(n,seed)); return 0; }
