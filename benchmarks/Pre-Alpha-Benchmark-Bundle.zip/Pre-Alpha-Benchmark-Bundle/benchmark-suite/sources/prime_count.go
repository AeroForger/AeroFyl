package main
import "fmt"

func work(n int64,seed int64) int64 { count := int64(0); candidate := int64(2); for (candidate<=n) { d := int64(2); prime := int64(1); for (d*d<=candidate) { if candidate-(candidate/d)*d==0 { prime=0; }; d=d+1; }; count=count+prime; candidate=candidate+1; }; return count+seed; }
func main() { var n,seed int64; fmt.Scan(&n,&seed); fmt.Println(work(n,seed)) }
