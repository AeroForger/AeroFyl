package main
import "fmt"

func work(n int32,seed int32) int32 { i := int32(0); x := int32(seed); for (i<n) { if i<n/2 { x=x+3; } else { x=x-1; }; i=i+1; }; return x; }
func main() { var n,seed int32; fmt.Scan(&n,&seed); fmt.Println(work(n,seed)) }
