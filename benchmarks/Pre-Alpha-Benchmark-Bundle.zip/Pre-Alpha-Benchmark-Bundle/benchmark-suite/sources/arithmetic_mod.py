def work(n,seed):
    i=0
    x=seed
    while i<n:
        x=x*31+17
        x=x-(x//1000003)*1000003
        i=i+1
    return x
if __name__=="__main__":
    import sys
    n,seed=map(int,sys.stdin.read().split())
    print(work(n,seed))
