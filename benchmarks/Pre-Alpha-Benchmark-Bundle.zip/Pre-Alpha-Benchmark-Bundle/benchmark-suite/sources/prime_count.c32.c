#include <stdio.h>
#include <stdint.h>
#include <inttypes.h>

int32_t work(int32_t n,int32_t seed) { int32_t count=0; int32_t candidate=2; while(candidate<=n) { int32_t d=2; int32_t prime=1; while(d*d<=candidate) { if(candidate-(candidate/d)*d==0) { prime=0; } d=d+1; } count=count+prime; candidate=candidate+1; } return count+seed; }
int main(void) { int32_t n,seed; if(scanf("%" SCNd32 " %" SCNd32,&n,&seed)!=2) return 2; printf("%" PRId32 "\n", work(n,seed)); return 0; }
