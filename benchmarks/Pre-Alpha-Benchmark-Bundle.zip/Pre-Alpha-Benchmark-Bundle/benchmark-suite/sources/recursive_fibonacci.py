def fib(x):
    if x<2:
        return x
    return fib(x-1)+fib(x-2)
def work(n,seed):
    return fib(n)+seed
if __name__=="__main__":
    import sys
    n,seed=map(int,sys.stdin.read().split())
    print(work(n,seed))
