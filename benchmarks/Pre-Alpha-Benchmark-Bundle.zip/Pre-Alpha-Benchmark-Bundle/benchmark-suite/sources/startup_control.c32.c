#include <stdio.h>
#include <stdint.h>
#include <inttypes.h>

int32_t work(int32_t n,int32_t seed) { return seed; }
int main(void) { int32_t n,seed; if(scanf("%" SCNd32 " %" SCNd32,&n,&seed)!=2) return 2; printf("%" PRId32 "\n", work(n,seed)); return 0; }
