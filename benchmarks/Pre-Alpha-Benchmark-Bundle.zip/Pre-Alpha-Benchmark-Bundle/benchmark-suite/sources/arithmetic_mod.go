package main
import "fmt"

func work(n int64,seed int64) int64 { i := int64(0); x := int64(seed); for (i<n) { x=x*31+17; x=x-(x/1000003)*1000003; i=i+1; }; return x; }
func main() { var n,seed int64; fmt.Scan(&n,&seed); fmt.Println(work(n,seed)) }
