def work(n,seed):
    return seed
if __name__=="__main__":
    import sys
    n,seed=map(int,sys.stdin.read().split())
    print(work(n,seed))
