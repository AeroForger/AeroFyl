package main
import "fmt"

func work(n int64,seed int64) int64 { return seed; }
func main() { var n,seed int64; fmt.Scan(&n,&seed); fmt.Println(work(n,seed)) }
