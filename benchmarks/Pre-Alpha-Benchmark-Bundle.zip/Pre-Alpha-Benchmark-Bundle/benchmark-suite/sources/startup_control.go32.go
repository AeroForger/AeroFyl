package main
import "fmt"

func work(n int32,seed int32) int32 { return seed; }
func main() { var n,seed int32; fmt.Scan(&n,&seed); fmt.Println(work(n,seed)) }
