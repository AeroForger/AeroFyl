#include <stdio.h>
#include <stdint.h>
#include <inttypes.h>
int32_t fib(int32_t x) { if(x<2) { return x; } return fib(x-1)+fib(x-2); }
int32_t work(int32_t n,int32_t seed) { return fib(n)+seed; }
int main(void) { int32_t n,seed; if(scanf("%" SCNd32 " %" SCNd32,&n,&seed)!=2) return 2; printf("%" PRId32 "\n", work(n,seed)); return 0; }
