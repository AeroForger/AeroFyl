#include <stdio.h>
#include <stdint.h>
#include <inttypes.h>
int32_t step(int32_t x) { int32_t y=x*3+7; return y-(y/1000003)*1000003; }
int32_t work(int32_t n,int32_t seed) { int32_t i=0; int32_t x=seed; while(i<n) { x=step(x); i=i+1; } return x; }
int main(void) { int32_t n,seed; if(scanf("%" SCNd32 " %" SCNd32,&n,&seed)!=2) return 2; printf("%" PRId32 "\n", work(n,seed)); return 0; }
