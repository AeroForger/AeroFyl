package main
import "fmt"
func fib(x int32) int32 { if x<2 { return x; }; return fib(x-1)+fib(x-2); }
func work(n int32,seed int32) int32 { return fib(n)+seed; }
func main() { var n,seed int32; fmt.Scan(&n,&seed); fmt.Println(work(n,seed)) }
