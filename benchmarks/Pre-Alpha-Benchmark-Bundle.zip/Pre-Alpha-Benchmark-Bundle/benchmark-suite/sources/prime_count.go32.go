package main
import "fmt"

func work(n int32,seed int32) int32 { count := int32(0); candidate := int32(2); for (candidate<=n) { d := int32(2); prime := int32(1); for (d*d<=candidate) { if candidate-(candidate/d)*d==0 { prime=0; }; d=d+1; }; count=count+prime; candidate=candidate+1; }; return count+seed; }
func main() { var n,seed int32; fmt.Scan(&n,&seed); fmt.Println(work(n,seed)) }
