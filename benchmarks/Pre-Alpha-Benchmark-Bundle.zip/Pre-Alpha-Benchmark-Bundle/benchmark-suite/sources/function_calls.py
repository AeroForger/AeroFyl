def step(x):
    y=x*3+7
    return y-(y//1000003)*1000003
def work(n,seed):
    i=0
    x=seed
    while i<n:
        x=step(x)
        i=i+1
    return x
if __name__=="__main__":
    import sys
    n,seed=map(int,sys.stdin.read().split())
    print(work(n,seed))
