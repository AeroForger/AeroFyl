#include <stdio.h>
#include <stdint.h>
#include <inttypes.h>

int64_t work(int64_t n,int64_t seed) { int64_t count=0; int64_t candidate=2; while(candidate<=n) { int64_t d=2; int64_t prime=1; while(d*d<=candidate) { if(candidate-(candidate/d)*d==0) { prime=0; } d=d+1; } count=count+prime; candidate=candidate+1; } return count+seed; }
int main(void) { int64_t n,seed; if(scanf("%" SCNd64 " %" SCNd64,&n,&seed)!=2) return 2; printf("%" PRId64 "\n", work(n,seed)); return 0; }
