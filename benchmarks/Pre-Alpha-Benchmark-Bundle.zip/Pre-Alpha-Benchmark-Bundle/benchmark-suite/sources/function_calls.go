package main
import "fmt"
func step(x int64) int64 { y := int64(x*3+7); return y-(y/1000003)*1000003; }
func work(n int64,seed int64) int64 { i := int64(0); x := int64(seed); for (i<n) { x=step(x); i=i+1; }; return x; }
func main() { var n,seed int64; fmt.Scan(&n,&seed); fmt.Println(work(n,seed)) }
