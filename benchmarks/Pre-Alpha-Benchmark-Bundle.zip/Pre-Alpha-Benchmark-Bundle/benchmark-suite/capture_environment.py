from pathlib import Path
import os,sys,json,subprocess,hashlib
root=Path(__file__).resolve().parent
# Called by reproduce.sh after building both pinned compilers.
repos=[Path(v).resolve() for v in sys.argv[1:]]
result={'repositories':{p.name:{'commit':subprocess.check_output(['git','-C',str(p),'rev-parse','HEAD'],text=True).strip(),'status':subprocess.check_output(['git','-C',str(p),'status','--porcelain'],text=True)} for p in repos},'rustc':subprocess.check_output(['rustc','+1.99.0','--version'],text=True).strip(),'cargo':subprocess.check_output(['cargo','+1.99.0','--version'],text=True).strip()}
result['compiler_sha256']={str(p/'target/release'/name):hashlib.sha256((p/'target/release'/name).read_bytes()).hexdigest() for p,name in zip(repos,['aerofyl-bootstrap','furnace'])}
for key,path in [('cgroup_cpu_max','/sys/fs/cgroup/cpu.max'),('cgroup_memory_max','/sys/fs/cgroup/memory.max')]:
    result[key]=Path(path).read_text().strip() if Path(path).exists() else 'unavailable'
(root/'environment.json').write_text(json.dumps(result,indent=2))
