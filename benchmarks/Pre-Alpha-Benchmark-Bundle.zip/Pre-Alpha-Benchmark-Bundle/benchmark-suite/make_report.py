from pathlib import Path
import json,math,statistics
root=Path(__file__).resolve().parent
r=json.loads((root/'results.json').read_text());e=json.loads((root/'environment.json').read_text());w=json.loads((root/'width-control.json').read_text());native=json.loads((root/'native-control.json').read_text());cases=json.loads((root/'cases.json').read_text())
workloads=[k for k in cases if k!='startup_control']
names={'arithmetic_mod':'Bounded arithmetic','predictable_branches':'Predictable branches','state_branches':'State-dependent branches','function_calls':'Function calls','recursive_fibonacci':'Recursive Fibonacci','prime_count':'Prime counting','startup_control':'Startup control'}
def gm(vals):return math.exp(statistics.mean(map(math.log,vals)))
def table(headers,rows):return '| '+' | '.join(headers)+' |\n| '+' | '.join(['---']*len(headers))+' |\n'+'\n'.join('| '+' | '.join(map(str,row))+' |' for row in rows)+'\n'
def ratios(label):return [r['summary'][k]['AeroFyl']['median_ms']/r['summary'][k][label]['median_ms'] for k in workloads]
text=f'''# AeroFyl documented benchmark: C, Python, Sydrogen and Go

Measured run started: **{r['timestamp_utc']}**. All timings are from the execution environment described below, **not Davit's laptop**. This is a scalar integer microbenchmark suite at pinned compiler revisions; its results do not establish a universal language-speed ranking.

## Observed results

All main-suite outputs passed 336 validation executions (seven programs × six input fixtures × eight configurations), followed by output checks on every warmup and timed execution. There were no failed comparisons.

Across the **six selected workloads**, the geometric mean of per-workload ratios was:

'''
rows=[]
for test,label in [('Test 1 — C','C-O3'),('Test 2 — Python','Python'),('Test 3 — Sydrogen (Cranelift, stdin)','Sydrogen-cranelift'),('Test 4 — Go','Go')]:
    x=gm(ratios(label));rows.append([test, f'AeroFyl {x:.2f}× slower' if x>1 else f'AeroFyl {1/x:.2f}× faster'])
text+=table(['Requested comparison','Measured geometric mean'],rows)
text+='''
A geometric mean gives each of these six workloads equal weight. It excludes the startup control and is not the ratio of total elapsed times. The per-workload numbers below are the primary result.

**Backend discovery:** at this Sydrogen revision, `Expr::Input(_)` and `Statement::Input(_)` cause native requests to fall back to the typed Cranelift path. Consequently, both stdin Sydrogen configurations in the main run used Cranelift. The separate fixed-input comparison below verifies actual direct-native output. The two main-run CLI configurations must not be presented as independent backend implementations.

## Environment and pinned sources

'''
text+=table(['Item','Observed configuration'],[
['CPU',next(line.split(':',1)[1].strip() for line in r['lscpu'].splitlines() if line.startswith('Model name:'))],
['Execution environment','KVM virtual machine; Linux x86-64'],['OS',r['platform']],['Affinity',f'Runner and child processes pinned to logical CPU {r["cpu_affinity"]}; original allowed set {r["allowed_cpus_before_pin"]}'],
['Resource limits',f'cpu.max={e["cgroup_cpu_max"]}; memory.max={e["cgroup_memory_max"]} bytes'],
['C',r['tool_versions']['gcc'].splitlines()[0]],['Python',r['python'].splitlines()[0]],['Go',r['tool_versions']['go']],['Rust compiler used to build both compilers',e['rustc']],
['AeroFyl',f'Stage 0 Rust bootstrap; commit `{e["repositories"]["AeroFyl"]["commit"]}`'],['Sydrogen',f'{r["tool_versions"]["furnace"]}; commit `{e["repositories"]["Sydrogen"]["commit"]}`']])
text+='''
Both compiler checkouts were clean and unmodified. Both compiler executables were built using `cargo build --release --locked`. A release build optimizes the **compiler executable**; it does not add an optimization flag to the generated AeroFyl or Sydrogen program.

Sources:

'''
af=e['repositories']['AeroFyl']['commit'];sy=e['repositories']['Sydrogen']['commit']
text+=f'''- [Pinned AeroFyl repository](https://github.com/AeroForger/AeroFyl/tree/{af})
- [AeroFyl CLI and available flags](https://github.com/AeroForger/AeroFyl/blob/{af}/bootstrap/rust/src/main.rs)
- [AeroFyl 64-bit integer semantics](https://github.com/AeroForger/AeroFyl/blob/{af}/bootstrap/rust/README.md)
- [Pinned Sydrogen repository](https://github.com/AeroForger/Sydrogen/tree/{sy})
- [Sydrogen backend dispatch and Input fallback](https://github.com/AeroForger/Sydrogen/blob/{sy}/src/backend/mod.rs)
- [Sydrogen Cranelift settings and integer lowering](https://github.com/AeroForger/Sydrogen/blob/{sy}/src/codegen.rs)

'''
text+='''## Protocol

1. Compile all programs before timing runtime execution. Use the real compilers from the pinned repositories; no compiler-source patches.
2. Read `n` and `seed` from stdin in the primary suite. Print one integer result. GCC and Go may optimize the program normally.
3. Compare all implementations against independent Python oracles: `%` recurrences, a closed-form branch result, iterative Fibonacci, and a sieve for prime counts. Validate five small/edge fixtures and the timed fixture per workload. Small cases include zero iterations, one iteration and different seeds.
4. Run two untimed warmups per configuration. Run 11 measured rounds per workload, shuffling configuration order in each round with RNG seed 4201.
5. Measure with Python `time.perf_counter_ns()` around `subprocess.run`. This is **process-start-to-exit wall time**, including program startup, input, output and the runner's subprocess overhead. Compilation is excluded. Programs run sequentially, with the runner and children pinned to one logical CPU.
6. Keep every sample. Report the median, minimum, maximum and median absolute deviation (MAD). No outlier removal, baseline subtraction or fastest-run selection.
7. Record tool versions, compiler hashes, source hashes, exact build commands, build stdout/stderr, validation results and raw timing samples.

The main suite has eight configurations: AeroFyl, GCC `-O0`, `-O2`, `-O3`, CPython, Go, Sydrogen `--backend native` (fallback), and Sydrogen `--backend cranelift`.

- AeroFyl uses its existing bootstrap CLI, with no unsupported optimization flags.
- Go uses `go build`, followed by execution of the built binary; `go run` is not timed.
- Python uses CPython without NumPy, PyPy or a JIT.
- Sydrogen's Cranelift setup leaves `opt_level` at the dependency's default `none`; the installed Cranelift 0.135.2 source confirms this default. No compiler optimization settings were changed.
- C uses `int64_t`, Go uses `int64`, AeroFyl uses its signed 64-bit `int`, and Sydrogen Cranelift uses 32-bit `Int`. Every tested value fits signed 32-bit. Separate C32 and Go32 controls make the width difference visible.
- All operands involved in division are nonnegative and divisors are positive. Python `//` therefore agrees with integer division in the compiled versions for these fixtures.
- AeroFyl does not accept `%` in this bootstrap. All timed versions use the equivalent expression `x - (x / divisor) * divisor`. The reference oracle uses `%`.

## Workload definitions

'''
text+=table(['Workload','n','seed','Algorithm'],[
[names['arithmetic_mod'],cases['arithmetic_mod']['n'],7,'Repeat x=(31x+17) mod 1,000,003 using division-based remainder'],
[names['predictable_branches'],cases['predictable_branches']['n'],7,'First floor(n/2) iterations add 3; remaining iterations subtract 1'],
[names['state_branches'],cases['state_branches']['n'],7,'Branch on x<500,001; use (31x+17) or (37x+11), then bounded remainder'],
[names['function_calls'],cases['function_calls']['n'],7,'Call step(x), returning (3x+7) mod 1,000,003'],
[names['recursive_fibonacci'],cases['recursive_fibonacci']['n'],7,'Naive recursive fib(n), then add seed; no memoization'],
[names['prime_count'],cases['prime_count']['n'],7,'Trial divide each candidate from 2 through n by every d with d*d<=candidate; no early exit; return count+seed'],
[names['startup_control'],0,7,'Read inputs and print seed; no kernel work']])
text+='''
The prime algorithm is deliberately identical across implementations, including its lack of an early exit. It is not a recommendation for implementing a prime generator. The state-dependent branch test is not asserted to produce any particular branch-prediction rate. Function calls may be inlined; this test measures the complete program, not the cost of a single machine-level call.

## Median runtime: all configurations

Milliseconds; lower is faster. “Syd N→CL” means native requested, Cranelift fallback used.

'''
cols=['AeroFyl','C-O0','C-O2','C-O3','Python','Go','Sydrogen-native','Sydrogen-cranelift']
text+=table(['Workload','AeroFyl','C O0','C O2','C O3','Python','Go','Syd N→CL','Syd CL'],[[names[k]]+[f'{r["summary"][k][label]["median_ms"]:.3f}' for label in cols] for k in cases])
text+='''
## Test 1 — AeroFyl versus C

Each ratio is **AeroFyl time / C time**. A value above 1 means AeroFyl took longer.

'''
text+=table(['Workload','vs O0','vs O2','vs O3'],[[names[k]]+[f'{r["summary"][k]["AeroFyl"]["median_ms"]/r["summary"][k][label]["median_ms"]:.2f}×' for label in ['C-O0','C-O2','C-O3']] for k in workloads])
text+='''
GCC-generated assembly is included for bounded arithmetic, function calls and predictable branches. In the function-call kernel, GCC O3's `work` loop has no call to `step`; its body contains the inlined calculation. Predictable-branch assembly contains loop transformations and unrolling. These tests therefore cannot establish that one language “excels at branches” independently of the rest of its generated program.

## Test 2 — AeroFyl versus Python

The speedup column is **Python time / AeroFyl time**.

'''
text+=table(['Workload','AeroFyl ms','Python ms','Measured AeroFyl speedup'],[[names[k],f'{r["summary"][k]["AeroFyl"]["median_ms"]:.3f}',f'{r["summary"][k]["Python"]["median_ms"]:.3f}',f'{1/x:.2f}×'] for k,x in zip(workloads,ratios('Python'))])
text+='''
AeroFyl was faster in all six measured kernels. This comparison includes CPython's interpreter startup and execution; it does not represent Python code delegated to compiled numerical libraries.

## Test 3 — AeroFyl versus Sydrogen

The primary stdin table compares AeroFyl against Sydrogen's typed Cranelift output. AeroFyl took longer in all six kernels in that phase.

For the actual direct-native comparison, a separate phase replaces only the `Input` initializers with the same literal `n` and `seed` in **both** AeroFyl and Sydrogen. The work functions and algorithms are retained. Each result is checked on every execution. `readelf -l` confirms no `INTERP` segment in AeroFyl and direct-native Sydrogen executables, while the fixed-input Cranelift executables have an interpreter segment. Full program headers are stored in `native-control.json`.

The first 11-round fixed-input run had substantial timing spikes. It is preserved in `native-control-first-run.json`. A rebuild attempt for that follow-up hit a 120-second timeout compiling `predictable_branches.fixed.fyl` with the unmodified AeroFyl compiler; the successful initial build is still retained. The timeout traceback is in `native-control-rebuild-timeout.log`. This documents a failed rebuild attempt, not a failure of the recorded runtime outputs. The follow-up reuses the compiled executables, verifies their ELF formats again, and checks outputs on every run. It uses **21 rounds**, two warmups, randomized order (seed 4203), on the same pinned CPU. All samples are retained. Compare within this phase, not against the earlier stdin phase.

'''
ncols=['AeroFyl-fixed','Sydrogen-direct-native-fixed','Sydrogen-cranelift-fixed']
text+=table(['Workload','AeroFyl fixed ms','Syd direct native ms','Syd CL fixed ms','Aero / direct native'],[[names[k]]+[f'{native["summary"][k][label]["median_ms"]:.3f}' for label in ncols]+[f'{native["summary"][k][ncols[0]]["median_ms"]/native["summary"][k][ncols[1]]["median_ms"]:.2f}×'] for k in cases])
ng=gm([native['summary'][k][ncols[0]]['median_ms']/native['summary'][k][ncols[1]]['median_ms'] for k in workloads])
text+=f'\nFor these six fixed-input kernels, AeroFyl took **{ng:.2f}×** as long as actual direct-native Sydrogen by the geometric mean. This is a separate experiment with fixed inputs.\n\n'
text+='''## Test 4 — AeroFyl versus Go

Ratio: **AeroFyl time / Go time**.

'''
text+=table(['Workload','AeroFyl ms','Go ms','Aero / Go'],[[names[k],f'{r["summary"][k]["AeroFyl"]["median_ms"]:.3f}',f'{r["summary"][k]["Go"]["median_ms"]:.3f}',f'{x:.2f}×'] for k,x in zip(workloads,ratios('Go'))])
text+='''
Go was faster in all six measured kernels. Both implementations used signed 64-bit arithmetic in this main comparison.

## Supplement: integer-width controls

This is another separate phase: C `int32_t` at O3, Go `int32`, remeasured AeroFyl, and remeasured Sydrogen Cranelift. It uses the same stdin cases, six validation fixtures per program and configuration, two warmups, 11 measured rounds, and shuffled order with seed 4202. All values and outputs agree with the same oracles.

'''
wcols=['AeroFyl','C32-O3','Go32','Sydrogen-cranelift']
text+=table(['Workload','AeroFyl ms','C32 O3 ms','Go32 ms','Syd CL32 ms'],[[names[k]]+[f'{w["summary"][k][label]["median_ms"]:.3f}' for label in wcols] for k in cases])
text+='''
For this phase, AeroFyl also took longer than each of these three controls in all six kernels. The 32-bit controls do not turn the main comparison into a same-width comparison; they document an additional comparison instead.

## Timing spread

Main phase: median [minimum–maximum] milliseconds. All 11 samples, and MAD, are in `results.json`. Shared virtual-machine scheduling and short process runtimes limit precision. Affinity constrains CPU selection; it does not give this run exclusive use of a physical core.

'''
text+=table(['Workload','AeroFyl','C O3','Python','Go','Syd CL'],[[names[k]]+[f'{r["summary"][k][label]["median_ms"]:.3f} [{r["summary"][k][label]["min_ms"]:.3f}–{r["summary"][k][label]["max_ms"]:.3f}]' for label in ['AeroFyl','C-O3','Python','Go','Sydrogen-cranelift']] for k in cases])
text+='\nFixed-input follow-up: median [minimum–maximum] ms.\n\n'
text+=table(['Workload','AeroFyl fixed','Syd direct native','Syd CL fixed'],[[names[k]]+[f'{native["summary"][k][label]["median_ms"]:.3f} [{native["summary"][k][label]["min_ms"]:.3f}–{native["summary"][k][label]["max_ms"]:.3f}]' for label in ncols] for k in cases])
text+='''
## Executable file sizes

Primary phase, minimum–maximum bytes across the seven compiled programs. These are on-disk executable sizes as emitted by the build commands, with no stripping step. Python's source size is not compared to executable sizes. Dynamically linked executables exclude external libraries; sizes are not complete installation footprints.

'''
text+=table(['Configuration','Min bytes','Max bytes'],[[label,min(r['builds'][k][label]['file_bytes'] for k in cases),max(r['builds'][k][label]['file_bytes'] for k in cases)] for label in cols if label!='Python'])
text+='''
The AeroFyl startup control was faster than all main-phase controls in the recorded median. Its ELF is statically linked without a program interpreter; the main-phase C, Go and Sydrogen programs are identified individually by the bundled `file` output. This observation is about tiny-process wall time and does not reverse the six kernel results.

## What this test covers and leaves open

**Measured:** these six scalar integer workloads, a startup control, eight main configurations, integer-width controls, verified direct-native Sydrogen output, output correctness for the stated fixtures, and executable file sizes.

**Not measured:** arrays/lists, allocation throughput, strings, floating point, SIMD, parallelism, files, networking, GPU execution, peak memory, energy, or performance on Davit's laptop. There is no claim about arbitrary programs or a distribution of real-world applications. These fixtures are finite checks, not proofs of compiler correctness.

The suite allows legitimate optimizations such as inlining and loop transformations. It does not force each implementation to execute the same number of machine instructions. Requiring that would change the question being tested.

Build wall times are recorded as single command observations in `results.json` and `build-record.json`, including warm Go build caches and system linking. They are **not** a controlled compiler-speed benchmark and are not ranked here.

## Reproduce

Prerequisites: Linux x86-64, GCC, Python 3, Git, `readelf`, rustup with Rust 1.99.0, and Go 1.27.1 on PATH. The package contains benchmark sources and scripts, not the language compilers or toolchains. `reproduce.sh` clones both repositories into a new `checkouts` directory and detaches them at the exact revisions above. It makes no remote writes.

```bash
rustup toolchain install 1.99.0 --profile minimal
# Install Go 1.27.1 using the official Go distribution for Linux amd64.
bash reproduce.sh
```

Equivalent main runtime commands, after building the compilers:

```bash
python3 generate.py
python3 run.py \\
  --aero checkouts/AeroFyl/target/release/aerofyl-bootstrap \\
  --furnace checkouts/Sydrogen/target/release/furnace \\
  --go go
python3 width_control.py --go go
python3 native_control.py \\
  --aero checkouts/AeroFyl/target/release/aerofyl-bootstrap \\
  --furnace checkouts/Sydrogen/target/release/furnace
python3 make_report.py
```

Exact original commands and absolute source paths are retained in the raw JSON. The reproduction script resolves its own directory, so the archive can be extracted elsewhere. Source SHA-256 values in the primary results allow comparison with the measured source files.

## Bundle contents

- `sources/`: each workload in AeroFyl, C, Python, Go and Sydrogen, plus width and fixed-input controls.
- `run.py`, `width_control.py`, `native_control.py`: build, validation and timing harnesses.
- `generate.py`, `cases.json`, `reproduce.sh`, `capture_environment.py`, `make_report.py`: generation and reproduction.
- `results.json`, `build-record.json`, `validation.json`, `environment.json`: primary raw results and environment evidence.
- `width-control.json`, `native-control.json`, `native-control-first-run.json`: supplementary samples and original noisy run.
- Build/run logs, executable-format records and selected GCC disassemblies.

No benchmark binaries or downloaded toolchains are included in the archive.
'''
(root/'AeroFyl-Benchmark-Report.md').write_text(text)
print('Report written:',len(text),'characters')
