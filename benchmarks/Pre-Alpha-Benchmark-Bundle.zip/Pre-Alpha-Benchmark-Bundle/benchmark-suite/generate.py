from pathlib import Path
import re,json
ROOT=Path(__file__).resolve().parent
# Bodies share structure and runtime inputs. All test values fit signed 32-bit.
CASES={
'arithmetic_mod':(5000000,7,'', '''int i=0; int x=seed; while(i<n) { x=x*31+17; x=x-(x/1000003)*1000003; i=i+1; } return x;''', '''i=0
x=seed
while i<n:
    x=x*31+17
    x=x-(x//1000003)*1000003
    i=i+1
return x'''),
'predictable_branches':(5000000,7,'', '''int i=0; int x=seed; while(i<n) { if(i<n/2) { x=x+3; } else { x=x-1; } i=i+1; } return x;''', '''i=0
x=seed
while i<n:
    if i<n//2:
        x=x+3
    else:
        x=x-1
    i=i+1
return x'''),
'state_branches':(5000000,7,'', '''int i=0; int x=seed; while(i<n) { if(x<500001) { x=x*31+17; x=x-(x/1000003)*1000003; } else { x=x*37+11; x=x-(x/1000003)*1000003; } i=i+1; } return x;''', '''i=0
x=seed
while i<n:
    if x<500001:
        x=x*31+17
        x=x-(x//1000003)*1000003
    else:
        x=x*37+11
        x=x-(x//1000003)*1000003
    i=i+1
return x'''),
'function_calls':(3000000,7,'''int step(int x) { int y=x*3+7; return y-(y/1000003)*1000003; }''', '''int i=0; int x=seed; while(i<n) { x=step(x); i=i+1; } return x;''', '''i=0
x=seed
while i<n:
    x=step(x)
    i=i+1
return x'''),
'recursive_fibonacci':(31,7,'''int fib(int x) { if(x<2) { return x; } return fib(x-1)+fib(x-2); }''', '''return fib(n)+seed;''', '''return fib(n)+seed'''),
'prime_count':(80000,7,'', '''int count=0; int candidate=2; while(candidate<=n) { int d=2; int prime=1; while(d*d<=candidate) { if(candidate-(candidate/d)*d==0) { prime=0; } d=d+1; } count=count+prime; candidate=candidate+1; } return count+seed;''', '''count=0
candidate=2
while candidate<=n:
    d=2
    prime=1
    while d*d<=candidate:
        if candidate-(candidate//d)*d==0:
            prime=0
        d=d+1
    count=count+prime
    candidate=candidate+1
return count+seed'''),
'startup_control':(0,7,'', 'return seed;', 'return seed')}

def go_body(s):
    s=re.sub(r'int (\w+)=([^;]+);',r'\1 := int64(\2);',s)
    s=s.replace('while(', 'for (')
    # Go requires no parentheses around if/for conditions.
    s=re.sub(r'(for|if)\((.*?)\) \{',r'\1 \2 {',s)
    return re.sub(r'} (?!else)', '}; ', s)

def go_helper(s):
    if not s:return ''
    s=re.sub(r'int (\w+)\(int (\w+)\)',r'func \1(\2 int64) int64',s)
    s=re.sub(r'int (\w+)=([^;]+);',r'\1 := int64(\2);',s)
    s=re.sub(r'if\((.*?)\) \{',r'if \1 {',s)
    return re.sub(r'} (?!else)', '}; ', s)

for name,(n,seed,helper,body,pybody) in CASES.items():
    c='''#include <stdio.h>\n#include <stdint.h>\n#include <inttypes.h>\n'''+re.sub(r'\bint\b','int64_t',helper)+'\nint64_t work(int64_t n,int64_t seed) { '+re.sub(r'\bint\b','int64_t',body)+''' }\nint main(void) { int64_t n,seed; if(scanf("%" SCNd64 " %" SCNd64,&n,&seed)!=2) return 2; printf("%" PRId64 "\\n", work(n,seed)); return 0; }\n'''
    fyl='use std.io;\n'+(('private '+helper+'\n') if helper else '')+'private int work(int n,int seed) { '+body+' }\npublic void main() { int n=input(int); int seed=input(int); println(work(n,seed)); }\n'
    syd=(helper+'\n' if helper else '')+'Int Work(Int n,Int seed) { '+body+' }\nOpen Nunction Main() { Int n=Input(Int); Int seed=Input(Int); Print(Work(n,seed)); }\n'
    syd=re.sub(r'\bint\b','Int',syd)
    for a,b in [('return','Return'),('while','While'),('if','If'),('else','Else')]: syd=re.sub(r'\b'+a+r'\b',b,syd)
    go='package main\nimport "fmt"\n'+go_helper(helper)+'\nfunc work(n int64,seed int64) int64 { '+go_body(body)+' }\nfunc main() { var n,seed int64; fmt.Scan(&n,&seed); fmt.Println(work(n,seed)) }\n'
    pyhelper=''
    if name=='function_calls':pyhelper='def step(x):\n    y=x*3+7\n    return y-(y//1000003)*1000003\n'
    if name=='recursive_fibonacci':pyhelper='def fib(x):\n    if x<2:\n        return x\n    return fib(x-1)+fib(x-2)\n'
    py=pyhelper+'def work(n,seed):\n'+'\n'.join('    '+l for l in pybody.splitlines())+'\nif __name__=="__main__":\n    import sys\n    n,seed=map(int,sys.stdin.read().split())\n    print(work(n,seed))\n'
    for ext,src in [('c',c),('fyl',fyl),('anvil',syd),('go',go),('py',py)]: (ROOT/'sources'/f'{name}.{ext}').write_text(src)
(ROOT/'cases.json').write_text(json.dumps({k:{'n':v[0],'seed':v[1]} for k,v in CASES.items()},indent=2))
