#!/usr/bin/env python3
from pathlib import Path
import argparse,json,os,subprocess,time,statistics,random
p=argparse.ArgumentParser();p.add_argument('--go',default='go');a=p.parse_args()
if '/' in a.go:a.go=str(Path(a.go).resolve())
root=Path(__file__).resolve().parent
r=json.loads((root/'results.json').read_text());os.sched_setaffinity(0,{r['cpu_affinity']})
cases=json.loads((root/'cases.json').read_text());outputs={};stats={};raw={};builds=[]
for name in cases:
    src=root/'sources'/f'{name}.c';dst=root/'sources'/f'{name}.c32.c';dst.write_text(src.read_text().replace('int64_t','int32_t').replace('SCNd64','SCNd32').replace('PRId64','PRId32'))
    go_src=root/'sources'/f'{name}.go';go_dst=root/'sources'/f'{name}.go32.go';go_dst.write_text(go_src.read_text().replace('int64','int32'))
    outputs[name]={}
    for label,cmd in [('C32-O3',['gcc','-std=c11','-O3',str(dst),'-o',str(root/'bin'/f'{name}.C32-O3')]),('Go32',[a.go,'build','-o',str(root/'bin'/f'{name}.Go32'),str(go_dst)])]:
        subprocess.run(cmd,check=True,capture_output=True);builds.append(cmd);outputs[name][label]=cmd[cmd.index('-o')+1]
# A separate phase with AeroFyl and Sydrogen32 controls remeasured alongside.
for name in cases:
    for label in ['AeroFyl','Sydrogen-cranelift']:outputs[name][label]=str(root/'bin'/f'{name}.{label}')

def one(name,label,fixture):
    t=time.perf_counter_ns();q=subprocess.run([outputs[name][label]],input=f'{fixture["n"]}\n{fixture["seed"]}\n',text=True,capture_output=True,timeout=60)
    ms=(time.perf_counter_ns()-t)/1e6
    assert q.returncode==0 and not q.stderr and q.stdout.strip()==str(fixture['expected']),(name,label,q.stdout,q.stderr)
    return ms
rng=random.Random(4202)
for name in cases:
    for fixture in r['validation'][name]:
        for label in outputs[name]:one(name,label,fixture)
    fixture=r['validation'][name][-1];raw[name]={label:[] for label in outputs[name]}
    for i in range(13):
        order=list(outputs[name]);rng.shuffle(order)
        for label in order:
            ms=one(name,label,fixture)
            if i>=2:raw[name][label].append(ms)
    stats[name]={label:{'median_ms':statistics.median(v),'min_ms':min(v),'max_ms':max(v)} for label,v in raw[name].items()}
    print(name,stats[name],flush=True)
(root/'width-control.json').write_text(json.dumps({'phase':'separate; interpret within this phase','cpu':r['cpu_affinity'],'rounds':11,'warmups':2,'build_commands':builds,'summary':stats,'samples':raw},indent=2))
