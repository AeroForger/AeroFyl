# AeroFyl benchmark package

Read `AeroFyl-Benchmark-Report.md` for the four requested comparisons, protocol, environment, backend caveat and limitations.

The bundle contains all workload sources, checked timing harnesses, exact commands, raw samples and logs. Compilers and downloaded toolchains are excluded.

To reproduce, install the prerequisites listed in the report and run `bash reproduce.sh` from a separate extracted copy. This writes fresh observations over the packaged results. No GitHub files are changed.

The primary stdin-based Sydrogen “native” configuration actually uses the compiler's Cranelift fallback. The fixed-input supplementary suite verifies actual native ELF output. The longer follow-up reused compiled executables after a rebuild attempt timed out; the full traceback is retained.
