#!/usr/bin/env python3
"""Compile, validate and benchmark the pinned five-language scalar suite."""
from pathlib import Path
import argparse,subprocess,os,sys,json,time,random,statistics,platform,hashlib,importlib.util
ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser()
p.add_argument('--aero',required=True)
p.add_argument('--furnace',required=True)
p.add_argument('--go',default='go')
p.add_argument('--gcc',default='gcc')
p.add_argument('--rounds',type=int,default=11)
p.add_argument('--validate-only',action='store_true')
a=p.parse_args()
for key in ['aero','furnace','go']:
    v=getattr(a,key)
    if '/' in v:setattr(a,key,str(Path(v).resolve()))
original_affinity=sorted(os.sched_getaffinity(0));cpu=original_affinity[0]
os.sched_setaffinity(0,{cpu})
cases=json.loads((ROOT/'cases.json').read_text())
labels=['AeroFyl','C-O0','C-O2','C-O3','Python','Go','Sydrogen-native','Sydrogen-cranelift']
result={'timestamp_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'platform':platform.platform(),'python':sys.version,'cpu_affinity':cpu,'allowed_cpus_before_pin':original_affinity,'rounds':a.rounds,'warmups':2,'order_rng_seed':4201,'builds':{},'validation':{},'samples':{},'summary':{}}
result['tool_versions']={k:subprocess.check_output(cmd,text=True).strip() for k,cmd in {'gcc':[a.gcc,'--version'],'go':[a.go,'version'],'furnace':[a.furnace,'--version']}.items()}
result['lscpu']=subprocess.check_output(['lscpu'],text=True)
result['kernel']=subprocess.check_output(['uname','-a'],text=True).strip()
result['source_sha256']={str(f.relative_to(ROOT)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted((ROOT/'sources').iterdir()) if f.is_file()}
commands={}
bindir=ROOT/'bin';bindir.mkdir(exist_ok=True)
for name in cases:
    commands[name]={};result['builds'][name]={}
    for label in labels:
        ext={'AeroFyl':'fyl','C-O0':'c','C-O2':'c','C-O3':'c','Python':'py','Go':'go','Sydrogen-native':'anvil','Sydrogen-cranelift':'anvil'}[label]
        src=ROOT/'sources'/f'{name}.{ext}';out=bindir/f'{name}.{label}'
        if label=='Python':commands[name][label]=[sys.executable,str(src)];continue
        if label=='AeroFyl':cmd=[a.aero,'compile',str(src),'-o',str(out)]
        elif label.startswith('C-'):cmd=[a.gcc,'-std=c11','-'+label.split('-')[1],str(src),'-o',str(out)]
        elif label=='Go':cmd=[a.go,'build','-o',str(out),str(src)]
        else:cmd=[a.furnace,'compile',str(src),'linux','--backend',label.split('-')[1]]
        t=time.perf_counter_ns();r=subprocess.run(cmd,cwd=bindir,capture_output=True,text=True,timeout=120)
        elapsed=(time.perf_counter_ns()-t)/1e6
        result['builds'][name][label]={'command':cmd,'wall_ms':elapsed,'stdout':r.stdout,'stderr':r.stderr,'returncode':r.returncode}
        if r.returncode: print(json.dumps(result['builds'][name][label],indent=2),flush=True);raise RuntimeError('build failed '+name+' '+label)
        if label.startswith('Sydrogen'): (bindir/name).replace(out)
        commands[name][label]=[str(out)]
        result['builds'][name][label]['file_bytes']=out.stat().st_size
    print('Built',name,flush=True)
(ROOT/'build-record.json').write_text(json.dumps(result,indent=2))

def oracle(name,n,seed):
    if name=='startup_control':return seed
    if name=='predictable_branches':return seed+3*(n//2)-(n-n//2)
    if name=='recursive_fibonacci':
        x,y=0,1
        for _ in range(n):x,y=y,x+y
        return x+seed
    if name=='prime_count':
        if n<2:return seed
        sieve=bytearray(b'\1')*(n+1);sieve[0:2]=b'\0\0'
        for d in range(2,int(n**0.5)+1):
            if sieve[d]:sieve[d*d:n+1:d]=b'\0'*len(range(d*d,n+1,d))
        return sum(sieve)+seed
    x=seed
    for _ in range(n):
        if name=='arithmetic_mod':x=(x*31+17)%1000003
        elif name=='state_branches':x=((x*31+17) if x<500001 else (x*37+11))%1000003
        elif name=='function_calls':x=(x*3+7)%1000003
        else:raise ValueError(name)
    return x

def run_checked(name,label,n,seed,expected):
    start=time.perf_counter_ns()
    proc=subprocess.run(commands[name][label],input=f'{n}\n{seed}\n',capture_output=True,text=True,timeout=60)
    elapsed=(time.perf_counter_ns()-start)/1e6
    if proc.returncode or proc.stderr or proc.stdout.strip()!=str(expected):
        raise RuntimeError(f'{name}/{label} n={n} seed={seed}: expected {expected}, got {proc.returncode} {proc.stdout!r} {proc.stderr!r}')
    return elapsed

for name,case in cases.items():
    fixtures=[(0,0),(1,7),(2,1),(17,999999),(100,7)] if name!='recursive_fibonacci' else [(0,0),(1,7),(2,1),(10,999999),(17,7)]
    result['validation'][name]=[]
    for n,seed in fixtures+[(case['n'],case['seed'])]:
        expected=oracle(name,n,seed)
        for label in labels:run_checked(name,label,n,seed,expected)
        result['validation'][name].append({'n':n,'seed':seed,'expected':expected,'passed':labels})
    print('Validated',name,flush=True)
(ROOT/'validation.json').write_text(json.dumps(result['validation'],indent=2))
if a.validate_only:sys.exit(0)
# All compilation is finished before collecting runtime samples.
rng=random.Random(4201)
for name,case in cases.items():
    n,seed=case['n'],case['seed'];expected=oracle(name,n,seed)
    result['samples'][name]={label:[] for label in labels}
    for _ in range(2):
        order=labels[:];rng.shuffle(order)
        for label in order:run_checked(name,label,n,seed,expected)
    for round_num in range(a.rounds):
        order=labels[:];rng.shuffle(order)
        for label in order:result['samples'][name][label].append(run_checked(name,label,n,seed,expected))
    result['summary'][name]={}
    for label,vals in result['samples'][name].items():
        median=statistics.median(vals)
        result['summary'][name][label]={'median_ms':median,'min_ms':min(vals),'max_ms':max(vals),'mad_ms':statistics.median(abs(v-median) for v in vals)}
    (ROOT/'results.json').write_text(json.dumps(result,indent=2))
    print('Measured',name,':',', '.join(f'{label} {s["median_ms"]:.3f} ms' for label,s in result['summary'][name].items()),flush=True)
